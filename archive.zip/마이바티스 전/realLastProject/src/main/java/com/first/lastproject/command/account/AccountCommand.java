package com.first.lastproject.command.account;

import org.springframework.ui.Model;

public interface AccountCommand {
	public String execute(Model model);	
}
