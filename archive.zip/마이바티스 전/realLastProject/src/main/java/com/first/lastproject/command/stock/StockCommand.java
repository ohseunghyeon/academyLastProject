package com.first.lastproject.command.stock;

import org.springframework.ui.Model;

public interface StockCommand {
	public String execute(Model model);	
}
