package com.first.lastproject.command.goods;

import org.springframework.ui.Model;

public interface GoodsCommand {
	public String execute(Model model);	
}
