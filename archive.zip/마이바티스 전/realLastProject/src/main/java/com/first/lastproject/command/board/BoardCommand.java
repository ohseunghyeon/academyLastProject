package com.first.lastproject.command.board;

import org.springframework.ui.Model;

public interface BoardCommand {

	public String execute(Model model);	
}
