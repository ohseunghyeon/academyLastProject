package com.first.lastproject.command.seat;

import org.springframework.ui.Model;

public interface SeatCommand {
	public String execute(Model model);	
}
