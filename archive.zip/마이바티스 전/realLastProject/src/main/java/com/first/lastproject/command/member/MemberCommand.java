package com.first.lastproject.command.member;

import org.springframework.ui.Model;

public interface MemberCommand {
	public String execute(Model model);	
}
