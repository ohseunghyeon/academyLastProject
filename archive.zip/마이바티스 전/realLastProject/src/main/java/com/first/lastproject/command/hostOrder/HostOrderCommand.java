package com.first.lastproject.command.hostOrder;

import org.springframework.ui.Model;

public interface HostOrderCommand {
	public String execute(Model model);
}
